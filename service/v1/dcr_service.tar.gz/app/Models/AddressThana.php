<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AddressThana extends Model
{
    protected $table = 'address_thanas';

    protected $primaryKey = 'address_thana_id';

    public $timestamps = false;
}
