<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Common;

/*
 * 1. Get Active payment getway
 * url: http://202.125.76.60/v1
 * parameters: {}
 *
 * */

class HomeController extends Controller
{
    public function index(){
        //return 'welcome';

        /*$compressed   = gzcompress('Compress megjghjghj');
        $uncompressed = gzuncompress($compressed);

        return $uncompressed;*/
        //return base64_encode('12345678');

        $allData = array(
            'oauth_token'=>'0dfgdfdf4411',
            'user_id'=>1,
            'doctor_id'=>33,
            'name'=>'prince',
            'contact_no'=>'[{"contact_no":"123456"},{"contact_no":"123456"}]',
            'email'=>'prince@bbil.com',
            'address_line1'=>'Shyamoli, Dhaka',
            'address_line2'=>'',
            'division'=>1,
            'district'=>2,
            'thana'=>1,
            'zip'=>'z12345',
            'qualification'=>'abc',
            'specialities'=>[1,2,3],
            'class'=>1,
            'special_days'=>'[{"special_day_id":1,"date":"1991-12-23","message":"Today is his birthday"},{"special_day_id":2,"date":"2017-03-12","message":"Today is his birthday"}]',
            'other_special_day'=>'[{"special_day":"day title1","date":"1991-12-23","message":"Today is his birthday"},{"special_day":"day title2","date":"2017-03-12","message":"Today is his birthday"}]',
            'chamber_address' => '[{"address_line1":"addr1","address_line2":"addr2","division":1,"district":2,"thana":1,"zip":"1234"},{"address_line1":"addr1.2","address_line2":"addr2.2","division":2,"district":1,"thana":5,"zip":"4321"}]'
        );

        $Data = json_encode($allData);

        return $Data;
    }

    public function testArray(){
        $allData = array(
            'oauth_token'=>'0dfgdfdf4411',
            'user_id'=>1,
            'name'=>'prince',
            'contact_no'=>'[{"contact_no":"123456"},{"contact_no":"987654"}]',
            'email'=>'prince@bbil.com',
            'address_line1'=>'Shyamoli, Dhaka',
            'address_line2'=>'',
            'division'=>1,
            'district'=>2,
            'thana'=>1,
            'zip'=>'z12345',
            'qualification'=>'abc',
            'specialities'=>array(1,2,3),
            'class'=>1,
            'special_days'=>'[{"special_day_id":1,"date":"1991-12-23","message":"Today is his birthday"},{"special_day_id":2,"date":"2017-03-12","message":"Today is his birthday"}]',
            'other_special_day'=>'[{"special_day":"day title1","date":"1991-12-23","message":"Today is his birthday"},{"special_day":"day title2","date":"2017-03-12","message":"Today is his birthday"}]',
            'chamber_address' => '[{"address_line1":"addr1","address_line2":"addr2","division":"div","district":"dist","thana":"thn","zip":"1234556"},{"address_line1":"addr1.2","address_line2":"addr2.2","division":"div","district":"dist","thana":"thn","zip":"1234556"}]'
        );
    }
}
