<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Region;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Common;
use Hash;

/*
 * 1. User search
 * url: http://202.125.76.60/v1/user/search
 * parameters: {token,oauth_token,name}
 *
 * */

class UserController extends Controller
{
    public function index(){
        //
    }

    public function userSearch(Request $request){
        if($request->token !=Common::TOKEN_USER){
            return json_encode(['status'=>401,'reason'=>'Invalid token']);
        }

        /*Check oauth token starts*/
        $user = User::where('active_oauth_token',$request->oauth_token)->first();
        if(empty($user)){
            return json_encode(['status'=>401,'reason'=>'Invalid oauth token']);
        }
        /*Check oauth token ends*/

        if($request->name ==''){
            return json_encode(['status'=>200,'data'=>[]]);
        }
        $users = User::select('users.id','users.first_name', 'users.last_name','roles.name as designation')
            ->Where('first_name', 'like', '%'.$request->name.'%')
            //->orWhere('last_name', 'like','%'. $request->name.'%')
            ->join('roles','roles.role_id','=','users.role_id')
            ->get();
        return json_encode(['status'=>200,'data'=>$users]);
    }

}
