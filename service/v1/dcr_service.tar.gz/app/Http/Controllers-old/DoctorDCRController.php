<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Doctor;
use App\Models\DoctorDcr;
use App\Models\DoctorDcrProduct;
use App\Common;
use DB;

/*
 * 1. Create Doctor DCR
 * url: http://satsai.com/dcr/doctor_dcr/create
 * parameters: {token,gzcompress(data)}
 * data = array(oauth_token,doctor_id,user_id,remark,time,products=[2,10])
 * *
 * 2. Update Doctor DCR
 * url: http://satsai.com/dcr/doctor_dcr/update
 * parameters: {token,gzcompress(data)}
 * data = array(oauth_token,doctor_dcr_id,doctor_id,user_id,remark,time,products=[2,10])
 *
 * */

class DoctorDcrController extends Controller
{
    public function index(){

    }

    public function create(Request $request){
        if($request->token !=Common::TOKEN_DOCTOR_DCR){
            return json_encode(['status'=>401,'reason'=>'Invalid token']);
        }

        $dcrData = gzuncompress($request->data);

        if($dcrData['doctor_id'] == ''){
            return json_encode(['status'=>401,'reason'=>'Doctor ID required']);
        }

        if($dcrData['user_id'] == ''){
            return json_encode(['status'=>401,'reason'=>'User ID required']);
        }

        /*Check oauth token starts*/
        $user = User::where('active_oauth_token',$dcrData['oauth_token'])->first();
        if(count($user)==0){
            return json_encode(['status'=>401,'reason'=>'Invalid oauth token']);
        }
        /*Check oauth token ends*/

        $dcr = NEW DoctorDcr();
        $dcr->doctor_id = $dcrData['doctor_id'];
        $dcr->user_id = $dcrData['user_id'];
        $dcr->remark = $dcrData['remark'];
        $dcr->time = $dcrData['time'];
        $dcr->save();

        // Adding dcr products
        $dcr_products = json_decode($dcr['products'],true);
        foreach($dcr_products as $product){
            $dcr_product = NEW DoctorDcrProduct();
            $dcr_product->doctor_dcr_id = $dcr->doctor_dcr_id;
            $dcr_product->product_id = $product;
            $dcr_product->save();
        }

        return json_encode(['status'=>200,'reason'=>'Successful','doctor_dcr_id'=>1]);

    }

    public function update(Request $request){
        if($request->token !=Common::TOKEN_DOCTOR_DCR){
            return json_encode(['status'=>401,'reason'=>'Invalid token']);
        }

        $dcrData = gzuncompress($request->data);

        if($dcrData['doctor_dcr_id'] == ''){
            return json_encode(['status'=>401,'reason'=>'Doctor dcr ID required']);
        }
        if($dcrData['doctor_id'] == ''){
            return json_encode(['status'=>401,'reason'=>'Doctor ID required']);
        }

        /*Check oauth token starts*/
        $user = User::where('active_oauth_token',$dcrData['oauth_token'])->first();
        if(count($user)==0){
            return json_encode(['status'=>401,'reason'=>'Invalid oauth token']);
        }
        /*Check oauth token ends*/


        $dcr = DoctorDcr::where('doctor_dcr_id',$dcrData['doctor_dcr_id'])->first();
        $dcr->doctor_id = $dcrData['doctor_id'];
        $dcr->user_id = $dcrData['user_id'];
        $dcr->remark = $dcrData['remark'];
        $dcr->time = $dcrData['time'];
        $dcr->save();

        // Adding doctor dcr products
        // First delete dcr products doctor dcr
        DoctorDcrProduct::where('doctor_dcr_id',$dcrData['doctor_dcr_id'])->delete();
        // Now add new home address
        $dcr_products = json_decode($dcr['products'],true);
        foreach($dcr_products as $product){
            $dcr_product = NEW DoctorDcrProduct();
            $dcr_product->doctor_dcr_id = $dcr->doctor_dcr_id;
            $dcr_product->product_id = $product;
            $dcr_product->save();
        }

        return json_encode(['status'=>200,'reason'=>'Successful']);


    }
}
