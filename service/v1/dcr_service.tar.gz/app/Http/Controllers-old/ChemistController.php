<?php

namespace App\Http\Controllers;

use App\Models\ChemistSpecialDay;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Chemist;
use App\Models\ChemistAddress;
use App\Models\ChemistContact;
use App\Models\ChemistTerritory;
use App\Models\ChemistSpecialDayTypes;
use App\Common;

/*
 * 1. Create Chemist
 * url: http://202.125.76.60/chemist/create
 * parameters: {token,gzcompress(data)}
 * data = {"oauth_token":"0dfgdfdf4411","user_id":1,"name":"prince","contact_no":"[{\"contact_no\":\"123456\"},{\"contact_no\":\"123456\"}]","email":"prince@bbil.com","address_line1":"Shyamoli, Dhaka","address_line2":"","division":1,"district":2,"thana":1,"zip":"z12345","territories":[1,2,3],"category_id":1,"class_id":2,"special_days":"[{\"special_day_id\":1,\"date\":\"1991-12-23\",\"message\":\"Today is his birthday\"},{\"special_day_id\":2,\"date\":\"2017-03-12\",\"message\":\"Today is his birthday\"}]","other_special_day":"[{\"special_day\":\"day title1\",\"date\":\"1991-12-23\",\"message\":\"Today is his birthday\"},{\"special_day\":\"day title2\",\"date\":\"2017-03-12\",\"message\":\"Today is his birthday\"}]","chamber_address":"[{\"address_line1\":\"addr1\",\"address_line2\":\"addr2\",\"division\":1,\"district\":2,\"thana\":1,\"zip\":\"1234\"},{\"address_line1\":\"addr1.2\",\"address_line2\":\"addr2.2\",\"division\":2,\"district\":1,\"thana\":5,\"zip\":\"4321\"}]"}

 *
 * 2. Filter Chemist
 * url: http://202.125.76.60/chemist/filter
 * parameters: {token,oauth_token,contact_no,territory,name}
 *
 * 3. Search Chemist
 * url: http://202.125.76.60/chemist/search
 * parameters: {token,oauth_token,name}
 *
 * 4. Update Chemist
 * url: http://202.125.76.60/chemist/update
 * parameters: {token,gzcompress(data)}
 * data = {"oauth_token":"0dfgdfdf4411","user_id":1,"chemist_id":9,"name":"prince","contact_no":"[{\"contact_no\":\"123456\"},{\"contact_no\":\"123456\"}]","email":"prince@bbil.com","address_line1":"Shyamoli, Dhaka","address_line2":"","division":1,"district":2,"thana":1,"zip":"z12345","territories":[1,2,3],"category_id":1,"class_id":2,"special_days":"[{\"special_day_id\":1,\"date\":\"1991-12-23\",\"message\":\"Today is his birthday\"},{\"special_day_id\":2,\"date\":\"2017-03-12\",\"message\":\"Today is his birthday\"}]","other_special_day":"[{\"special_day\":\"day title1\",\"date\":\"1991-12-23\",\"message\":\"Today is his birthday\"},{\"special_day\":\"day title2\",\"date\":\"2017-03-12\",\"message\":\"Today is his birthday\"}]","chamber_address":"[{\"address_line1\":\"addr1\",\"address_line2\":\"addr2\",\"division\":1,\"district\":2,\"thana\":1,\"zip\":\"1234\"},{\"address_line1\":\"addr1.2\",\"address_line2\":\"addr2.2\",\"division\":2,\"district\":1,\"thana\":5,\"zip\":\"4321\"}]"}
 *
 * 5. Chemist Details
 * url: http://202.125.76.60/chemist/details
 * parameters: {token,oauth_token,chemist_id}
 *
 * 6. Chemist Special Day Types
 * url: http://202.125.76.60/chemist/special_day_types
 * parameters: {token,oauth_token}
 * */

class ChemistController extends Controller
{
    public function index(){

    }


    public function create(Request $request){
        if($request->token !=Common::TOKEN_CHEMIST){
            return json_encode(['status'=>401,'reason'=>'Invalid token']);
        }

        //$chemistData = gzuncompress($request->data);
        $chemistData = json_decode($request->data,true);

        if($chemistData['contact_no'] == ''){
            return json_encode(['status'=>401,'reason'=>'Contact number required']);
        }

        if($chemistData['user_id'] == ''){
            return json_encode(['status'=>401,'reason'=>'User ID required']);
        }

        if($chemistData['name'] == ''){
            return json_encode(['status'=>401,'reason'=>'Name required']);
        }

        /*Check oauth token starts*/
        $user = User::where('active_oauth_token',$chemistData['oauth_token'])->first();
        if(empty($user)){
            return json_encode(['status'=>401,'reason'=>'Invalid oauth token']);
        }
        /*Check oauth token ends*/

        $chemist = NEW Chemist();
        $chemist->name = $chemistData['name'];
        $chemist->category_id = $chemistData['category_id'];
        $chemist->class_id = $chemistData['class_id'];
        $chemist->created_by = $chemistData['user_id'];
        $chemist->other_special_day = $chemistData['other_special_day'];
        $chemist->save();

        /*
         * Adding chemist contact numbers
         */
        $contact_nos = json_decode($chemistData['contact_no'],true);
        foreach($contact_nos as $contact_no){
            $contact = NEW ChemistContact();
            $contact->chemist_id = $chemist->chemist_id;
            $contact->contact_no = $contact_no['contact_no'];
            $contact->save();
        }

        /*
         * Save chemist address
         */
        $address = NEW ChemistAddress();
        $address->chemist_id = $chemist->chemist_id;
        $address->address_line1	 = $chemistData['address_line1'];
        $address->address_line2	 = $chemistData['address_line2'];
        $address->division	 = $chemistData['division']	;
        $address->district	 = $chemistData['district']	;
        $address->thana	 = $chemistData['thana']	;
        $address->zip	 = $chemistData['zip']	;
        $address->save();

        /*
         * Adding chemist territories
         */
        //$territories = json_decode($chemistData['territories'],true);
        $territories = $chemistData['territories'];
        foreach($territories as $ter){
            $territory = NEW ChemistTerritory();
            $territory->chemist_id = $chemist->chemist_id;
            $territory->territory_id = $ter;
            $contact->save();
        }

        /*
         * Adding chemist special days
         */
        $special_days = json_decode($chemistData['special_days'],true);
        foreach($special_days as $special_day){
            $specialDay = NEW ChemistSpecialDay();
            $specialDay->chemist_id = $chemist->chemist_id;
            $specialDay->special_day_id = $special_day['special_day_id'];
            $specialDay->message = $special_day['message'];
            $specialDay->date = date('Y-m-d', strtotime($special_day['date']));
            $specialDay->save();
        }

        return json_encode(['status'=>200,'reason'=>'Successfully created','chemist_id'=>$chemist->chemist_id]);

    }

    public function filter(Request $request){
        if($request->token !=Common::TOKEN_CHEMIST){
            return json_encode(['status'=>401,'reason'=>'Invalid token']);
        }

        /*Check oauth token starts*/
        $user = User::where('active_oauth_token',$request->oauth_token)->first();
        if(empty($user)){
            return json_encode(['status'=>401,'reason'=>'Invalid oauth token']);
        }
        /*Check oauth token ends*/

        /*if($request->name == ''){
            return json_encode(['status'=>401,'reason'=>'Name required'];
        }*/

        /*
         * Search chemist based on territory
        */
        $chemists = array();
        $chemist_name = array();

        $territories = ChemistTerritory::select('chemists.*')->where('territory_id',$request->territory)
            ->where('chemist_contacts.contact_no',$request->contact_no)
            ->join('chemists','chemists.chemist_id','chemist_territories.chemist_id')
            ->leftJoin('chemist_contacts','chemist_contacts.chemist_id','chemist_territories.chemist_id')
            ->get();
        if(count($territories)==0){
            return json_encode(['status'=>200,'data'=>$chemists]);
        }
        else{
            foreach($territories as $territory){
                $chemist['chemist_id'] = $territory->chemist_id;
                $chemist['name'] = $territory->name;
                array_push($chemists,$chemist);
            }
        }

        if($request->name !=''){
            foreach($chemists as $chem){
                if(strpos($chem->name, $request->name) === 0){
                    $doctor['chemist_id'] = $chem->doctor_id;
                    $doctor['name'] = $chem->name;
                    array_push($chemist_name,$doctor);
                }
            }
            if(count($chemist_name)!=0){
                $chemists = $chemist_name;
            }
        }

        return json_encode(['status'=>200,'data'=>$chemists]);
    }

    public function search(Request $request){
        if($request->token !=Common::TOKEN_CHEMIST){
            return json_encode(['status'=>401,'reason'=>'Invalid token']);
        }

        /*Check oauth token starts*/
        $user = User::where('active_oauth_token',$request->oauth_token)->first();
        if(empty($user)){
            return json_encode(['status'=>401,'reason'=>'Invalid oauth token']);
        }
        /*Check oauth token ends*/

        /*
         * Search chemist based on name
        */

        $chemists = Chemist::select('chemists.*')->where('name','like','%'.$request->name.'%')->get();

        return json_encode(['status'=>200,'data'=>$chemists]);
    }

    public function update(Request $request){
        if($request->token !=Common::TOKEN_CHEMIST){
            return json_encode(['status'=>401,'reason'=>'Invalid token']);
        }

        //$chemistData = gzuncompress($request->data);
        $chemistData = json_decode($request->data,true);

        if($chemistData['user_id'] == ''){
            return json_encode(['status'=>401,'reason'=>'User ID required']);
        }

        if($chemistData['chemist_id'] == ''){
            return json_encode(['status'=>401,'reason'=>'Chemist id required']);
        }

        if($chemistData['contact_no'] == ''){
            return json_encode(['status'=>401,'reason'=>'Contact number required']);
        }

        if($chemistData['name'] == ''){
            return json_encode(['status'=>401,'reason'=>'Name required']);
        }

        /*Check oauth token starts*/
        $user = User::where('active_oauth_token',$chemistData['oauth_token'])->first();
        if(empty($user)){
            return json_encode(['status'=>401,'reason'=>'Invalid oauth token']);
        }
        /*Check oauth token ends*/

        $chemist = Chemist::where('chemist_id',$chemistData['chemist_id'])->first();
        $chemist->name = $chemistData['name'];
        $chemist->category_id = $chemistData['category_id'];
        $chemist->class_id = $chemistData['class_id'];
        $chemist->updated_by = $chemistData['user_id'];
        $chemist->other_special_day = $chemistData['other_special_day'];
        $chemist->save();

        /*
         * Adding chemist contact numbers
         */
        $contact_nos = json_decode($chemistData['contact_no'],true);
        // First delete contacts for this chemist
        ChemistContact::where('chemist_id',$chemistData['chemist_id'])->delete();
        // Now add new contacts
        foreach($contact_nos as $contact_no){
            $contact = NEW ChemistContact();
            $contact->chemist_id = $chemistData['chemist_id'];
            $contact->contact_no = $contact_no['contact_no'];
            $contact->save();
        }

        /*
         * Save chemist address
         */
        // First delete address for this chemist
        ChemistAddress::where('chemist_id',$chemistData['chemist_id'])->delete();
        // Now add new address
        $address = NEW ChemistAddress();
        $address->chemist_id = $chemist->chemist_id;
        $address->address_line1	 = $chemistData['address_line1'];
        $address->address_line2	 = $chemistData['address_line2'];
        $address->division	 = $chemistData['division']	;
        $address->district	 = $chemistData['district']	;
        $address->thana	 = $chemistData['thana']	;
        $address->zip	 = $chemistData['zip']	;
        $address->save();

        /*
         * Adding chemist contact numbers
         */
        $contact_nos = json_decode($chemistData['contact_no'],true);
        // First delete territiry for this chemist
        ChemistTerritory::where('chemist_id',$chemistData['chemist_id'])->delete();
        // Now add new territory
        //$territories = json_decode($chemistData['territories'],true);
        $territories = $chemistData['territories'];
        foreach($territories as $ter){
            $territory = NEW ChemistTerritory();
            $territory->chemist_id = $chemistData['chemist_id'];
            $territory->territory_id = $ter;
            $contact->save();
        }

        // Adding chemist special days
        $special_days = json_decode($chemistData['special_days'],true);
        // First delete special days for this chemist
        ChemistSpecialDay::where('chemist_id',$chemistData['chemist_id'])->delete();
        // Now add new special days
        foreach($special_days as $special_day){
            $specialDay = NEW ChemistSpecialDay();
            $specialDay->chemist_id = $chemistData['chemist_id'];
            $specialDay->special_day_id = $special_day['special_day_id'];
            $specialDay->message = $special_day['message'];
            $specialDay->date = date('Y-m-d', strtotime($special_day['date']));
            $specialDay->save();
        }

        return json_encode(['status'=>200,'reason'=>'Successful']);

    }

    public function details(Request $request){
        if($request->token !=Common::TOKEN_CHEMIST){
            return json_encode(['status'=>401,'reason'=>'Invalid token']);
        }

        /*Check oauth token starts*/
        $user = User::where('active_oauth_token',$request->oauth_token)->first();
        if(empty($user)){
            return json_encode(['status'=>401,'reason'=>'Invalid oauth token']);
        }
        /*Check oauth token ends*/

        $chemist = Chemist::where('chemist_id',$request->chemist_id)->first();
        return json_encode(['status'=>200,'data'=>json_encode($chemist)]);
    }

    public function specialDayTypes(Request $request){
        if($request->token !=Common::TOKEN_CHEMIST){
            return json_encode(['status'=>401,'reason'=>'Invalid token']);
        }

        /*Check oauth token starts*/
        $user = User::where('active_oauth_token',$request->oauth_token)->first();
        if(empty($user)){
            return json_encode(['status'=>401,'reason'=>'Invalid oauth token']);
        }
        /*Check oauth token ends*/

        $special_day_types = ChemistSpecialDayTypes::get();
        return json_encode(['status'=>200,'data'=>$special_day_types]);
    }
}
