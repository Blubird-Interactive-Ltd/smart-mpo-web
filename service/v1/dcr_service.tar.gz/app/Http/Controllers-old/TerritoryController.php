<?php

namespace App\Http\Controllers;

use App\Models\Region;
use Illuminate\Http\Request;
use App\Models\Territory;
use App\Common;
use Hash;

/*
 * 1. Territory list
 * url: http://satsai.com/dcr/v1/territory/list
 * parameters: {token}
 *
 * */

class TerritoryController extends Controller
{
    public function index(){

    }

    public function territoryList(Request $request){
        if($request->token !=Common::TOKEN_TERRITORY){
            return json_encode(['status'=>401,'reason'=>'Invalid token']);
        }
        $territories = Territory::get();
        return json_encode(['status'=>200,'reason'=>'','data'=>$territories]);
    }
}
