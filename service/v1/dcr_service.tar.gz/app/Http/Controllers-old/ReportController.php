<?php

namespace App\Http\Controllers;

use App\Models\SpecialDays;
use App\Models\DoctorSpecialDay;
use App\Models\ChemistSpecialDay;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Doctor;
use App\Models\Prescription;
use App\Common;
use DB;

/*
 * 1. Prescription report
 * url: http://202.125.76.60/v1/report/prescription
 * parameters: {token,user_id,oauth_token}
 *
 * 2. special Day Count for calendar
 * url: http://202.125.76.60/v1/calendar/special_day_count
 * parameters: {token,user_id,oauth_token}
 *
 * 2. calendar Day Details
 * url: http://202.125.76.60/v1/calendar/calendar_day_details
 * parameters: {token,oauth_token,date}
 *
 * */

class ReportController extends Controller
{
    public function index(){

    }

    /**
     * @param Request $request
     * @return array
     */
    public function prescription(Request $request){
        if($request->token !=Common::TOKEN_REPORT){
            return json_encode(['status'=>401,'reason'=>'Invalid token']);
        }
        if($request->user_id ==''){
            return json_encode(['status'=>401,'reason'=>'User ID required']);
        }

        /*Check oauth token starts*/
        $user = User::where('active_oauth_token',$request->oauth_token)->first();
        if(empty($user)){
            return json_encode(['status'=>401,'reason'=>'Invalid oauth token']);
        }
        /*Check oauth token ends*/

        $rawQuery = "SELECT created_at as date, SUM(CASE WHEN status='accepted' THEN 1 ELSE 0 END) as accepted, SUM(CASE WHEN status='rejected' THEN 1 ELSE 0 END) as rejected, SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) as pending, SUM(1) as total FROM prescriptions WHERE user_id = ".$request->user_id." GROUP BY created_at DESC";

        $prescriptions = DB::select($rawQuery);
        if(count($prescriptions)==0){
            return json_encode(['status'=>200,'reason'=>'empty','data'=>array()]);
        }

        return json_encode(['status'=>200,'reason'=>'','data'=>$prescriptions]);

    }

    public function specialDayCount(Request $request){

        if($request->token !=Common::TOKEN_REPORT){
            return json_encode(['status'=>401,'reason'=>'Invalid token']);
        }
        if($request->user_id ==''){
            return json_encode(['status'=>401,'reason'=>'User ID required']);
        }

        /*Check oauth token starts*/
        $user = User::where('active_oauth_token',$request->oauth_token)->first();
        if(empty($user)){
            return json_encode(['status'=>401,'reason'=>'Invalid oauth token']);
        }
        /*Check oauth token ends*/

        $start_date = date('Y-m-01');
        $end_date = date('Y-m-t');

        $rawQuery = "SELECT date,SUM(1) as total FROM system_special_days WHERE date >= ".$start_date." AND date <= ".$end_date." GROUP BY date";
        $system_special_days = DB::select($rawQuery);

        $rawQuery2 = "SELECT date,SUM(1) as total FROM doctor_special_days JOIN doctors ON doctors.doctor_id = doctor_special_days.doctor_id WHERE doctors.created_by = ".$request->user_id." AND date >= ".$start_date." AND date <= ".$end_date." GROUP BY date";
        $doctor_special_days = DB::select($rawQuery2);

        $rawQuery3 = "SELECT date,SUM(1) as total FROM chemist_special_days JOIN chemists ON chemists.chemist_id = chemist_special_days.chemist_id WHERE chemists.created_by = ".$request->user_id." AND date >= ".$start_date." AND date <= ".$end_date." GROUP BY date";
        $chemist_special_days = DB::select($rawQuery3);

        $final_array = array_merge($system_special_days, $doctor_special_days, $chemist_special_days);

        $sumArray = array();
        foreach ($final_array as $subArray) {
            $day = date('d',strtotime($subArray->date));
            if(isset($sumArray[$day])){
                $sumArray[$day] = $sumArray[$day]+$subArray->total;
            }
            else{
                $sumArray[$day] = $subArray->total;
            }
        }
        return json_encode(['status'=>200,'data'=>$sumArray]);
    }

    public function calendarDayDetails(Request $request){

        if($request->token !=Common::TOKEN_REPORT){
            return json_encode(['status'=>401,'reason'=>'Invalid token']);
        }
        if($request->date ==''){
            return json_encode(['status'=>401,'reason'=>'Date required']);
        }

        /*Check oauth token starts*/
        $user = User::where('active_oauth_token',$request->oauth_token)->first();
        if(empty($user)){
            return json_encode(['status'=>401,'reason'=>'Invalid oauth token']);
        }
        /*Check oauth token ends*/

        $date = date('Y-m-d', strtotime($request->date));
        $messages = array();

        $system_special_days = SpecialDays::where('date',$date);
        foreach($system_special_days as $sp_days){
            array_push($messages,$sp_days->message);
        }

        $doctor_special_days = DoctorSpecialDay::where('date',$date)
            ->join('doctor_special_day_types','doctor_special_day_types.doctor_special_day_type_id','=','doctor_special_days.special_day_id')
            ->join('doctors','doctors.doctor_id','=','doctor_special_days.doctor_id')
            ->get();
        foreach($doctor_special_days as $d_days){
            array_push($messages,$d_days->message);
        }

        $chemist_special_days = ChemistSpecialDay::where('date',$date)
            ->join('chemist_special_day_types','chemist_special_day_types.chemist_special_day_type_id','=','chemist_special_days.special_day_id')
            ->join('chemists','chemists.chemist_id','=','chemist_special_days.chemist_id')
            ->get();
        foreach($chemist_special_days as $c_days){
            array_push($messages,$c_days->message);
        }
        return json_encode(['status'=>200,'data'=>$messages]);
    }
}
