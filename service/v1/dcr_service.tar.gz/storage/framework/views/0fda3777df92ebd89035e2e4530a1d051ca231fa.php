<?php $__env->startSection('content'); ?>
    <div class="flex-center position-ref full-height">
        <div class="content">
            <form id="active_getway_form" method="post" action="">
                <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" id="token">

                <label>Active your payment getway</label>
                <input type="radio" name="active_getway" value="sslcommerz" <?php if($setting->payment_getway=='sslcommerz'): ?> checked <?php endif; ?>>Sslcommerz
                <input type="radio" name="active_getway" value="paypal" <?php if($setting->payment_getway=='paypal'): ?> checked <?php endif; ?>>Paypal

                </br>
                <button type="button" id="active_getway_button">Submit</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function(){

        });

        $(document).on('click','#active_getway_button',function(){
            var formData = new FormData($('#active_getway_form')[0]);
            var url = '<?php echo e(url('admin/update_payment_getway')); ?>';
            $.ajax({
                type: "POST",
                url: url,
                data: formData,
                async: false,
                success: function (data) {
                    if(data.status == 200){
                        alert(data.reason);
                        //location.reload();
                    }
                    else{
                        alert(data.reason);
                    }
                },
                cache: false,
                contentType: false,
                processData: false
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>